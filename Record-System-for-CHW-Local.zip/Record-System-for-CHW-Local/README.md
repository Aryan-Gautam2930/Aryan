# Record System for CHW — Local Presentation Build

A self-contained browser-based demonstration of a Community Health Worker record system. It is designed to be easy to open in Visual Studio Code or Visual Studio and run locally, with no package installation or backend required.

## Quick start

1. Download and extract the ZIP.
2. Open the extracted `Record-System-for-CHW-Local` folder in **Visual Studio Code** or **Visual Studio 2026**.
3. Open `index.html` in a browser.

### Recommended: run with VS Code Live Server

1. Open the folder in VS Code.
2. Install the **Live Server** extension if you do not already have it.
3. Right-click `index.html` → **Open with Live Server**.

You can also double-click `index.html` to open it directly in a modern browser. Internet is not required for app functionality; the optional Google Fonts import only affects typography.

## Features in this local demo

- Local demo sign-in with a display name
- Patient record creation, editing, deletion and search
- Patient profile fields: sex, DOB, age, weight, blood group, area
- Visit logs with symptoms/issues, care notes and optional follow-up date
- Reminders that can be marked complete
- Dashboard overview
- English, Hindi and Marathi language selector (key interface labels)
- CSV export for patient records
- JSON backup and restore
- Responsive layout for desktop and mobile screens
- Local browser storage; no backend needed

The app seeds a few **fictional demo records** on the first run so the dashboard looks populated during a presentation. You can delete them and add your own demonstration records.

## Data and security limitations — please read

- This is a **local presentation/demo build**, not a production medical-record system.
- Records are saved in the browser's `localStorage` for the current browser profile. They do not sync between devices and are not encrypted by this app.
- The name/PIN screen is a convenience demo only, not secure authentication. Do not use it to protect real patient data.
- No SMS, push notifications, cloud sync, or clinical decision-making is implemented.
- Use fictional data for demonstrations. Do not store real patient health information in this demo.
- For a production system, use a properly secured backend, real authentication, strict authorization/row-level security, encryption, audit logs, backups, and review by qualified security and healthcare professionals.

## Customization

Edit:
- `index.html` for structure and form fields
- `styles.css` for colors, spacing, typography and responsive layout
- `app.js` for record handling, validation, language labels and browser storage

Your edits affect only the local folder. They will not change the public GitHub repository unless you intentionally commit and push your changes.

## Reset demo data

Use **Settings & data → Clear all local records**. This clears records from the current browser's local storage. Refreshing after clearing will not automatically re-seed the examples because the local database key already exists.

## Original source repository

https://github.com/Aryan-Gautam2930/Aryan
